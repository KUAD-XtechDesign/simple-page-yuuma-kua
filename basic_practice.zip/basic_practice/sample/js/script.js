
$(function(){
  
  $("#slide").slick({dots:true});

  // $(".btn").on("click",()=>{
  //   $("#slide").slideToggle();
  // })

});